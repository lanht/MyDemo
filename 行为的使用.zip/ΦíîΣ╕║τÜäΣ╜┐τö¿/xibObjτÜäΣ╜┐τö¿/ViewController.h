//
//  ViewController.h
//  xibObj的使用
//
//  Created by yh on 16/8/22.
//  Copyright © 2016年 ld. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

