//
//  WBTabBarViewController.swift
//  WeiBo
//
//  Created by cp316 on 17/3/3.
//  Copyright © 2017年 lanht. All rights reserved.
//

import UIKit

class WBTabBarViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUpChildViewControllers()
        for item in tabBar.items! as [UITabBarItem] {
            item.setTitleTextAttributes([NSFontAttributeName : UIFont.systemFont(ofSize: 30)], for:UIControlState.normal)
            item.setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.red], for:UIControlState.normal)
//            item.setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.white], for:UIControlState.disabled)
            item.setTitleTextAttributes([NSForegroundColorAttributeName: UIColor(red: 171.0/255.0, green: 203.0/255.0, blue: 61.0/255.0, alpha: 1)], for:UIControlState.selected)
        }
    }
}

extension WBTabBarViewController {
     func setUpChildViewControllers() {
        let array = [
            ["clsName":"WBHomeViewController","title":"首页","imageName":"home"],
            ["clsName":"WBMassageViewController","title":"消息","imageName":"home"],
            ["clsName":"WBDiscoverViewController","title":"发现","imageName":"home"],
            ["clsName":"WBUserCenterViewController","title":"我的","imageName":"home"],
        ]
        
        var arrayM = [UIViewController]()
        for dict in array {
            arrayM.append(controller(dict: dict))
        }
        viewControllers = arrayM;
    }
    
    private func controller(dict:[String : String]) -> UIViewController {
        guard let clsName = dict["clsName"],
        let title = dict["title"],
        let imageName = dict["imageName"],
        let cls = NSClassFromString(Bundle.main.nameSpace() + "." + clsName) as? UIViewController.Type
        else {
            return UIViewController()
        }
        let vc = cls.init()
        vc.title = title
        vc.tabBarItem.image = UIImage.init(named: imageName)

        let nav = WBNavigationController.init(rootViewController:vc);
        return nav;
    }
}
